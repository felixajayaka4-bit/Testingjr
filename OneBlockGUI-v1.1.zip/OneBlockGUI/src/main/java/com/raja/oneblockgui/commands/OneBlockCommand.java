package com.raja.oneblockgui.commands;

import com.raja.oneblockgui.OneBlockGUI;
import com.raja.oneblockgui.gui.OneBlockMenu;
import com.raja.oneblockgui.managers.IslandManager.Island;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.*;

public class OneBlockCommand implements TabExecutor {

    private static final List<String> SUB = List.of("start", "home", "invite", "join", "leave", "kick", "info", "top");
    private final OneBlockGUI plugin;

    public OneBlockCommand(OneBlockGUI plugin) { this.plugin = plugin; }

    private UUID byName(Collection<UUID> ids, String name) {
        for (UUID id : ids) if (plugin.getIslandManager().name(id).equalsIgnoreCase(name)) return id;
        return null;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] a) {
        if (!(sender instanceof Player p)) { sender.sendMessage("§cCommand ini cuma bisa dipakai in-game."); return true; }
        var im = plugin.getIslandManager();
        String sub = a.length == 0 ? "" : a[0].toLowerCase();
        String arg = a.length > 1 ? a[1] : null;

        switch (sub) {
            case "start", "home" -> im.teleportHome(p);
            case "leave" -> im.leave(p);
            case "info" -> im.info(p);
            case "top" -> im.top(p);
            case "invite" -> {
                Player t = arg == null ? null : Bukkit.getPlayerExact(arg);
                if (t == null) p.sendMessage("§cPakai: /oneblock invite <player online>");
                else im.invite(p, t);
            }
            case "join" -> {
                UUID owner = arg == null ? null : byName(plugin.getInviteManager().getInvitesFor(p.getUniqueId()), arg);
                if (owner == null) p.sendMessage("§cKamu tidak punya undangan dari player itu!");
                else im.join(p, owner);
            }
            case "kick" -> {
                UUID t = arg == null ? null : byName(im.membersOf(p.getUniqueId()), arg);
                if (t == null) p.sendMessage("§cPakai: /oneblock kick <anggota>");
                else im.kick(p, t);
            }
            default -> p.openInventory(OneBlockMenu.mainMenu(p, plugin));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) return SUB.stream().filter(x -> x.startsWith(a[0].toLowerCase())).toList();
        if (a.length == 2 && s instanceof Player p) {
            List<String> r = new ArrayList<>();
            switch (a[0].toLowerCase()) {
                case "invite" -> Bukkit.getOnlinePlayers().forEach(o -> r.add(o.getName()));
                case "join" -> plugin.getInviteManager().getInvitesFor(p.getUniqueId())
                        .forEach(id -> r.add(plugin.getIslandManager().name(id)));
                case "kick" -> plugin.getIslandManager().membersOf(p.getUniqueId())
                        .forEach(id -> r.add(plugin.getIslandManager().name(id)));
            }
            return r.stream().filter(x -> x.toLowerCase().startsWith(a[1].toLowerCase())).toList();
        }
        return List.of();
    }
}
