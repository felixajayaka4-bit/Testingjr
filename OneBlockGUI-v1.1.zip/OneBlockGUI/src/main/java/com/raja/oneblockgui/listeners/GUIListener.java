package com.raja.oneblockgui.listeners;

import com.raja.oneblockgui.OneBlockGUI;
import com.raja.oneblockgui.gui.OneBlockMenu;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.UUID;

public class GUIListener implements Listener {

    private final OneBlockGUI plugin;

    public GUIListener(OneBlockGUI plugin) { this.plugin = plugin; }

    private boolean isMenu(InventoryHolder h) {
        return h instanceof OneBlockMenu.MainHolder || h instanceof OneBlockMenu.InviteHolder
                || h instanceof OneBlockMenu.JoinHolder;
    }

    // buka menu di tick berikutnya (aman dari glitch buka inventory di dalam event klik)
    private void open(Player p, Inventory inv) {
        Bukkit.getScheduler().runTask(plugin, () -> p.openInventory(inv));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (isMenu(e.getInventory().getHolder())) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        InventoryHolder holder = e.getInventory().getHolder();
        if (!isMenu(holder)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;
        if (e.getCurrentItem() == null || !(e.getWhoClicked() instanceof Player p)) return;
        int slot = e.getSlot();
        var im = plugin.getIslandManager();

        if (holder instanceof OneBlockMenu.MainHolder) {
            switch (slot) {
                case 10 -> { p.closeInventory(); im.teleportHome(p); }
                case 12 -> open(p, OneBlockMenu.inviteMenu(p));
                case 14 -> open(p, OneBlockMenu.joinMenu(plugin.getInviteManager().getInvitesFor(p.getUniqueId())));
                case 16 -> { p.closeInventory(); im.top(p); }
                case 22 -> { p.closeInventory(); im.leave(p); }
            }
        } else if (holder instanceof OneBlockMenu.InviteHolder h) {
            if (slot >= h.listed.size()) return;
            Player t = Bukkit.getPlayer(h.listed.get(slot));
            p.closeInventory();
            if (t == null) { p.sendMessage("§cPlayer itu sudah offline!"); return; }
            im.invite(p, t);
        } else if (holder instanceof OneBlockMenu.JoinHolder h) {
            if (slot >= h.listed.size()) return;
            UUID owner = h.listed.get(slot);
            p.closeInventory();
            im.join(p, owner);
        }
    }
}
