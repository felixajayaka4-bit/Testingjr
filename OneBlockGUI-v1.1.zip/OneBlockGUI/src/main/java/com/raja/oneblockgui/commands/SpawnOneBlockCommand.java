package com.raja.oneblockgui.commands;

import com.raja.oneblockgui.OneBlockGUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpawnOneBlockCommand implements CommandExecutor {

    private final OneBlockGUI plugin;

    public SpawnOneBlockCommand(OneBlockGUI plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage("§cCommand ini cuma bisa dipakai in-game."); return true; }
        if (!p.hasPermission("oneblock.admin")) { p.sendMessage("§cCuma operator yang bisa pakai ini!"); return true; }

        if (args.length > 0 && args[0].equalsIgnoreCase("remove")) {
            int n = plugin.getNpcManager().removeNear(p.getLocation(), 3);
            p.sendMessage(n > 0 ? "§aNPC OneBlock terdekat dihapus." : "§cTidak ada NPC OneBlock dalam 3 blok.");
            return true;
        }
        plugin.getNpcManager().spawnNPC(p.getLocation());
        p.sendMessage("§aNPC OneBlock di-spawn! §7(hapus: /spawnoneblock remove)");
        return true;
    }
}
