package com.raja.oneblockgui.listeners;

import com.raja.oneblockgui.OneBlockGUI;
import com.raja.oneblockgui.managers.IslandManager;
import com.raja.oneblockgui.managers.IslandManager.Island;
import org.bukkit.GameMode;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;

public class IslandListener implements Listener {

    private final OneBlockGUI plugin;

    public IslandListener(OneBlockGUI plugin) { this.plugin = plugin; }

    private IslandManager im() { return plugin.getIslandManager(); }

    private void give(Player p, ItemStack it) {
        p.getInventory().addItem(it).values().forEach(r -> p.getWorld().dropItemNaturally(p.getLocation(), r));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        Player p = e.getPlayer();
        if (!b.getWorld().getName().equals(IslandManager.WORLD)) return;

        Island is = im().at(b.getLocation());
        if (!im().canBuild(p, is)) {
            e.setCancelled(true);
            p.sendMessage("§cIni bukan island kamu!");
            return;
        }
        if (is == null || !im().isOneBlock(is, b)) return;

        if (p.getGameMode() != GameMode.CREATIVE) {
            e.setDropItems(false);
            if (b.getState() instanceof Container c) { // isi chest langsung ke tas
                for (ItemStack it : c.getInventory().getContents()) if (it != null) give(p, it);
                c.getInventory().clear();
            }
            for (ItemStack d : b.getDrops(p.getInventory().getItemInMainHand(), p)) give(p, d); // auto-pickup
        }
        im().broke(p, is);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Block b = e.getBlock();
        if (!b.getWorld().getName().equals(IslandManager.WORLD)) return;
        Island is = im().at(b.getLocation());
        if (!im().canBuild(e.getPlayer(), is)) {
            e.setCancelled(true);
            e.getPlayer().sendMessage("§cIni bukan island kamu!");
        }
    }

    // jatuh ke void -> balik ke island, bukan mati
    @EventHandler
    public void onVoid(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.VOID || !(e.getEntity() instanceof Player p)) return;
        if (!p.getWorld().getName().equals(IslandManager.WORLD)) return;
        Island is = im().getIsland(p.getUniqueId());
        if (is == null) return;
        e.setCancelled(true);
        p.setFallDistance(0);
        p.teleport(im().home(is));
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        if (e.isBedSpawn() || e.isAnchorSpawn()) return;
        Island is = im().getIsland(e.getPlayer().getUniqueId());
        if (is != null) e.setRespawnLocation(im().home(is));
    }
}
