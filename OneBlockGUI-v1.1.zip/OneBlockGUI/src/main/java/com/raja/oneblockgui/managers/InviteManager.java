package com.raja.oneblockgui.managers;

import java.util.*;

public class InviteManager {

    private static final long TTL = 60_000L;
    // key = yang diundang, value = (pengundang -> waktu kadaluarsa)
    private final Map<UUID, Map<UUID, Long>> pending = new HashMap<>();

    public void invite(UUID inviter, UUID target) {
        pending.computeIfAbsent(target, k -> new LinkedHashMap<>()).put(inviter, System.currentTimeMillis() + TTL);
    }

    public List<UUID> getInvitesFor(UUID target) {
        Map<UUID, Long> m = pending.get(target);
        if (m == null) return List.of();
        long now = System.currentTimeMillis();
        m.values().removeIf(t -> t < now);
        return new ArrayList<>(m.keySet());
    }

    public boolean remove(UUID target, UUID inviter) {
        return getInvitesFor(target).contains(inviter) && pending.get(target).remove(inviter) != null;
    }

    public void clear(UUID target) { pending.remove(target); }
}
