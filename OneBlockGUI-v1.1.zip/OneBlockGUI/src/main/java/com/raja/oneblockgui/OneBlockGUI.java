package com.raja.oneblockgui;

import com.raja.oneblockgui.commands.OneBlockCommand;
import com.raja.oneblockgui.commands.SpawnOneBlockCommand;
import com.raja.oneblockgui.listeners.GUIListener;
import com.raja.oneblockgui.listeners.IslandListener;
import com.raja.oneblockgui.listeners.NPCListener;
import com.raja.oneblockgui.managers.InviteManager;
import com.raja.oneblockgui.managers.IslandManager;
import com.raja.oneblockgui.managers.NPCManager;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

public class OneBlockGUI extends JavaPlugin {

    private NamespacedKey npcKey;
    private NPCManager npcManager;
    private InviteManager inviteManager;
    private IslandManager islandManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        npcKey = new NamespacedKey(this, "oneblock_npc");
        npcManager = new NPCManager(this);
        inviteManager = new InviteManager();
        islandManager = new IslandManager(this);
        islandManager.init();

        getCommand("spawnoneblock").setExecutor(new SpawnOneBlockCommand(this));
        OneBlockCommand cmd = new OneBlockCommand(this);
        getCommand("oneblock").setExecutor(cmd);
        getCommand("oneblock").setTabCompleter(cmd);

        getServer().getPluginManager().registerEvents(new NPCListener(this), this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);
        getServer().getPluginManager().registerEvents(new IslandListener(this), this);

        // spawn NPC setelah semua world siap
        getServer().getScheduler().runTask(this, npcManager::loadFromConfig);
        getLogger().info("OneBlockGUI aktif! Dibuat oleh Felix Kevin Chang.");
    }

    @Override
    public void onDisable() {
        if (islandManager != null) islandManager.save();
        if (npcManager != null) npcManager.removeAllNPCs();
    }

    public NamespacedKey getNpcKey() { return npcKey; }
    public NPCManager getNpcManager() { return npcManager; }
    public InviteManager getInviteManager() { return inviteManager; }
    public IslandManager getIslandManager() { return islandManager; }
}
