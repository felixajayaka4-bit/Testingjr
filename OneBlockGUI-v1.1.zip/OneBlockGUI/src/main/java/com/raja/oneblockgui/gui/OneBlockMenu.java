package com.raja.oneblockgui.gui;

import com.raja.oneblockgui.OneBlockGUI;
import com.raja.oneblockgui.managers.IslandManager.Island;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class OneBlockMenu {

    public static class MainHolder implements InventoryHolder {
        public Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }

    public static class InviteHolder implements InventoryHolder {
        public Inventory inventory;
        public List<UUID> listed = new ArrayList<>();
        @Override public Inventory getInventory() { return inventory; }
    }

    public static class JoinHolder implements InventoryHolder {
        public Inventory inventory;
        public List<UUID> listed = new ArrayList<>();
        @Override public Inventory getInventory() { return inventory; }
    }

    public static Inventory mainMenu(Player viewer, OneBlockGUI plugin) {
        MainHolder h = new MainHolder();
        Inventory inv = Bukkit.createInventory(h, 27, "§6§lOneBlock Menu");
        h.inventory = inv;

        Island is = plugin.getIslandManager().getIsland(viewer.getUniqueId());
        List<String> lore = new ArrayList<>();
        if (is == null) lore.add("§7Klik buat bikin island OneBlock kamu");
        else { lore.addAll(plugin.getIslandManager().stats(is)); lore.add(""); lore.add("§eKlik buat teleport"); }
        inv.setItem(10, item(Material.GRASS_BLOCK, is == null ? "§a§lMulai OneBlock" : "§a§lIsland Saya", lore));

        inv.setItem(12, item(Material.PLAYER_HEAD, "§b§lUndang Teman", List.of("§7Undang player online ke island kamu")));
        int n = plugin.getInviteManager().getInvitesFor(viewer.getUniqueId()).size();
        inv.setItem(14, item(Material.ENDER_PEARL, "§d§lGabung Teman",
                List.of("§7Undangan masuk: §e" + n, "§7Klik buat lihat & terima")));
        inv.setItem(16, item(Material.GOLDEN_HELMET, "§e§lTop OneBlock", List.of("§7Lihat peringkat island terbaik")));
        inv.setItem(22, item(Material.OAK_DOOR, "§c§lKeluar Island Teman", List.of("§7Balik ke island kamu sendiri")));

        for (int i = 0; i < 27; i++) {
            if (inv.getItem(i) != null) continue;
            boolean edge = i < 9 || i > 17;
            inv.setItem(i, item(edge && i % 2 == 0 ? Material.LIGHT_BLUE_STAINED_GLASS_PANE : Material.GRAY_STAINED_GLASS_PANE, " ", List.of()));
        }
        return inv;
    }

    public static Inventory inviteMenu(Player viewer) {
        InviteHolder h = new InviteHolder();
        Inventory inv = Bukkit.createInventory(h, 54, "§b§lUndang Teman - Pilih Player");
        h.inventory = inv;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.equals(viewer) || h.listed.size() >= 54) continue;
            inv.setItem(h.listed.size(), skull(p, "§e" + p.getName(), "§7Klik buat kirim undangan"));
            h.listed.add(p.getUniqueId());
        }
        if (h.listed.isEmpty()) inv.setItem(22, item(Material.BARRIER, "§cTidak ada player lain online", List.of()));
        return inv;
    }

    public static Inventory joinMenu(List<UUID> inviters) {
        JoinHolder h = new JoinHolder();
        Inventory inv = Bukkit.createInventory(h, 54, "§d§lUndangan Masuk");
        h.inventory = inv;
        for (UUID id : inviters) {
            if (h.listed.size() >= 54) break;
            String name = Bukkit.getOfflinePlayer(id).getName();
            inv.setItem(h.listed.size(), skull(Bukkit.getOfflinePlayer(id), "§a" + (name == null ? "Unknown" : name),
                    "§7Klik buat terima & teleport ke island ini"));
            h.listed.add(id);
        }
        if (inviters.isEmpty()) inv.setItem(22, item(Material.BARRIER, "§cBelum ada undangan",
                List.of("§7Minta teman undang lewat menu Undang Teman")));
        return inv;
    }

    private static ItemStack skull(org.bukkit.OfflinePlayer p, String name, String lore) {
        ItemStack s = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta m = (SkullMeta) s.getItemMeta();
        m.setOwningPlayer(p);
        m.setDisplayName(name);
        m.setLore(List.of(lore));
        s.setItemMeta(m);
        return s;
    }

    private static ItemStack item(Material mat, String name, List<String> lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(name);
        if (!lore.isEmpty()) m.setLore(lore);
        it.setItemMeta(m);
        return it;
    }
}
