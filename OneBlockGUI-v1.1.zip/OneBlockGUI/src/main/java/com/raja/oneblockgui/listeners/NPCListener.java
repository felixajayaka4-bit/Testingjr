package com.raja.oneblockgui.listeners;

import com.raja.oneblockgui.OneBlockGUI;
import com.raja.oneblockgui.gui.OneBlockMenu;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;

public class NPCListener implements Listener {

    private final OneBlockGUI plugin;

    public NPCListener(OneBlockGUI plugin) { this.plugin = plugin; }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent event) {
        if (!plugin.getNpcManager().isOneBlockNPC(event.getRightClicked())) return;
        event.setCancelled(true);
        if (event.getHand() != EquipmentSlot.HAND) return; // cegah menu kebuka 2x
        Player p = event.getPlayer();
        p.openInventory(OneBlockMenu.mainMenu(p, plugin));
    }
}
