package com.raja.oneblockgui.managers;

import com.raja.oneblockgui.OneBlockGUI;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class IslandManager {

    public static final String WORLD = "oneblock_world";
    public static final int SPACING = 300, Y = 64, GRID = 100;

    public static class Island {
        public final UUID owner;
        public final int index;
        public final Set<UUID> members = new HashSet<>();
        public int count;
        Island(UUID owner, int index) { this.owner = owner; this.index = index; }
        public int cx() { return (index % GRID) * SPACING; }
        public int cz() { return (index / GRID) * SPACING; }
    }

    public record Phase(String name, int from, Material[] blocks, EntityType[] mobs, Material[] loot) {}

    private static Material[] m(Material... a) { return a; }
    private static EntityType[] e(EntityType... a) { return a; }

    private final List<Phase> phases = List.of(
        new Phase("§aDataran", 0,
            m(Material.GRASS_BLOCK, Material.DIRT, Material.OAK_LOG, Material.OAK_LEAVES, Material.SAND,
              Material.GRAVEL, Material.COBBLESTONE, Material.COAL_ORE),
            e(EntityType.COW, EntityType.PIG, EntityType.SHEEP, EntityType.CHICKEN),
            m(Material.BREAD, Material.APPLE, Material.OAK_SAPLING, Material.WHEAT_SEEDS, Material.BONE_MEAL,
              Material.WATER_BUCKET, Material.LAVA_BUCKET)),
        new Phase("§7Gua Batu", 200,
            m(Material.STONE, Material.COBBLESTONE, Material.ANDESITE, Material.DIORITE, Material.GRANITE,
              Material.COAL_ORE, Material.IRON_ORE, Material.COPPER_ORE, Material.GOLD_ORE,
              Material.REDSTONE_ORE, Material.LAPIS_ORE),
            e(EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER),
            m(Material.IRON_INGOT, Material.COAL, Material.TORCH, Material.ARROW, Material.LAPIS_LAZULI,
              Material.COOKED_BEEF)),
        new Phase("§cNether", 600,
            m(Material.NETHERRACK, Material.SOUL_SAND, Material.NETHER_QUARTZ_ORE, Material.NETHER_GOLD_ORE,
              Material.MAGMA_BLOCK, Material.GLOWSTONE, Material.BLACKSTONE),
            e(EntityType.ZOMBIFIED_PIGLIN, EntityType.MAGMA_CUBE, EntityType.BLAZE),
            m(Material.GOLD_INGOT, Material.QUARTZ, Material.BLAZE_ROD, Material.GLOWSTONE_DUST)),
        new Phase("§8Deepslate", 1200,
            m(Material.DEEPSLATE, Material.COBBLED_DEEPSLATE, Material.TUFF, Material.CALCITE,
              Material.DEEPSLATE_IRON_ORE, Material.DEEPSLATE_GOLD_ORE, Material.DEEPSLATE_REDSTONE_ORE,
              Material.DEEPSLATE_LAPIS_ORE, Material.DEEPSLATE_DIAMOND_ORE, Material.ANCIENT_DEBRIS),
            e(EntityType.CREEPER, EntityType.SKELETON, EntityType.ZOMBIE),
            m(Material.DIAMOND, Material.IRON_INGOT, Material.GOLD_INGOT, Material.REDSTONE, Material.GOLDEN_APPLE)),
        new Phase("§5The End", 2000,
            m(Material.END_STONE, Material.OBSIDIAN, Material.PURPUR_BLOCK, Material.DIAMOND_ORE,
              Material.EMERALD_ORE, Material.END_STONE_BRICKS),
            e(EntityType.ENDERMAN),
            m(Material.DIAMOND, Material.EMERALD, Material.ENDER_PEARL, Material.GOLDEN_APPLE, Material.NETHERITE_SCRAP))
    );

    private final OneBlockGUI plugin;
    private final Map<UUID, Island> islands = new HashMap<>();
    private final Map<Integer, Island> byIndex = new HashMap<>();
    private final Map<UUID, UUID> active = new HashMap<>(); // player -> owner island yang lagi dipakai
    private final File file;
    private final Random rnd = new Random();
    private World world;
    private int nextIndex = 0;

    public IslandManager(OneBlockGUI plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "islands.yml");
    }

    // ---------- init / data ----------
    public void init() {
        load();
        world();
        var s = Bukkit.getScheduler();
        // jaga-jaga oneblock hilang (air/cairan/ledakan)
        s.runTaskTimer(plugin, () -> {
            for (Player p : world().getPlayers()) {
                Island is = at(p.getLocation());
                if (is != null) regen(is);
            }
        }, 100L, 100L);
        s.runTaskTimer(plugin, this::save, 6000L, 6000L);
    }

    public World world() {
        if (world == null) {
            world = Bukkit.getWorld(WORLD);
            if (world == null) world = new WorldCreator(WORLD).generator(new VoidGen()).createWorld();
            world.setSpawnLocation(0, Y + 1, 0);
        }
        return world;
    }

    private static class VoidGen extends ChunkGenerator {
        @Override public Location getFixedSpawnLocation(World w, Random r) { return new Location(w, 0.5, Y + 1, 0.5); }
    }

    private void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection s = y.getConfigurationSection("islands");
        if (s != null) for (String k : s.getKeys(false)) {
            Island is = new Island(UUID.fromString(k), s.getInt(k + ".index"));
            is.count = s.getInt(k + ".count");
            for (String mm : s.getStringList(k + ".members")) is.members.add(UUID.fromString(mm));
            islands.put(is.owner, is);
            byIndex.put(is.index, is);
            nextIndex = Math.max(nextIndex, is.index + 1);
        }
        ConfigurationSection a = y.getConfigurationSection("active");
        if (a != null) for (String k : a.getKeys(false)) active.put(UUID.fromString(k), UUID.fromString(a.getString(k)));
    }

    public synchronized void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Island is : islands.values()) {
            String k = "islands." + is.owner;
            y.set(k + ".index", is.index);
            y.set(k + ".count", is.count);
            y.set(k + ".members", is.members.stream().map(UUID::toString).toList());
        }
        active.forEach((p, o) -> y.set("active." + p, o.toString()));
        try { plugin.getDataFolder().mkdirs(); y.save(file); }
        catch (IOException ex) { plugin.getLogger().warning("Gagal simpan islands.yml: " + ex.getMessage()); }
    }

    // ---------- island ----------
    public Island getIsland(UUID p) {
        UUID o = active.get(p);
        Island is = o == null ? null : islands.get(o);
        if (is != null && !is.owner.equals(p) && !is.members.contains(p)) { // udah di-kick
            active.remove(p);
            is = null;
        }
        return is != null ? is : islands.get(p);
    }

    public Island create(UUID p) {
        Island is = islands.get(p);
        if (is != null) return is;
        is = new Island(p, nextIndex++);
        islands.put(p, is);
        byIndex.put(is.index, is);
        int cx = is.cx(), cz = is.cz();
        for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++) world().getBlockAt(cx + dx, Y - 1, cz + dz).setType(Material.GRASS_BLOCK);
        world().getBlockAt(cx, Y, cz).setType(Material.GRASS_BLOCK);
        save();
        return is;
    }

    public Location home(Island is) { return new Location(world(), is.cx() + 0.5, Y, is.cz() + 2.5, 180, 0); }

    public void teleportHome(Player p) {
        boolean fresh = !islands.containsKey(p.getUniqueId()) && getIsland(p.getUniqueId()) == null;
        Island is = getIsland(p.getUniqueId());
        if (is == null) is = create(p.getUniqueId());
        p.teleport(home(is));
        p.sendMessage(fresh ? "§aIsland OneBlock kamu dibuat! Hancurkan blok di depanmu!" : "§aTeleport ke island...");
    }

    public Island at(Location l) {
        if (l.getWorld() == null || !l.getWorld().getName().equals(WORLD)) return null;
        int ix = Math.round((float) l.getBlockX() / SPACING), iz = Math.round((float) l.getBlockZ() / SPACING);
        if (ix < 0 || ix >= GRID || iz < 0) return null;
        return byIndex.get(iz * GRID + ix);
    }

    public boolean isOneBlock(Island is, Block b) {
        return b.getX() == is.cx() && b.getY() == Y && b.getZ() == is.cz();
    }

    public boolean canBuild(Player p, Island is) {
        return p.hasPermission("oneblock.admin")
                || (is != null && (is.owner.equals(p.getUniqueId()) || is.members.contains(p.getUniqueId())));
    }

    // ---------- fase & generator ----------
    public Phase phase(int count) {
        Phase r = phases.get(0);
        for (Phase ph : phases) if (ph.from() <= count) r = ph;
        return r;
    }

    public Phase nextPhase(int count) {
        for (Phase ph : phases) if (ph.from() > count) return ph;
        return null;
    }

    private <T> T pick(T[] a) { return a[rnd.nextInt(a.length)]; }

    public void broke(Player p, Island is) {
        is.count++;
        Phase ph = phase(is.count);
        if (is.count > 0 && ph.from() == is.count) {
            for (Player x : onlineMembers(is)) {
                x.sendTitle("§6§lFASE BARU!", ph.name(), 10, 50, 10);
                x.playSound(x.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            }
        }
        Phase nx = nextPhase(is.count);
        p.sendActionBar(LegacyComponentSerializer.legacySection().deserialize(
                ph.name() + " §7| §a" + is.count + (nx != null ? "§7/§e" + nx.from() : "")));
        Bukkit.getScheduler().runTask(plugin, () -> regen(is));
    }

    public void regen(Island is) {
        Block b = world().getBlockAt(is.cx(), Y, is.cz());
        if (!b.getType().isAir()) return;
        Phase ph = phase(is.count);
        if (is.count > 0 && is.count % 64 == 0) { // chest loot tiap 64 blok
            b.setType(Material.CHEST);
            if (b.getState() instanceof Container c) {
                for (int i = 0, n = 3 + rnd.nextInt(4); i < n; i++) {
                    Material mat = pick(ph.loot());
                    c.getInventory().addItem(new ItemStack(mat, Math.min(1 + rnd.nextInt(4), mat.getMaxStackSize())));
                }
            }
            return;
        }
        if (rnd.nextInt(100) < 6)
            world().spawnEntity(b.getLocation().add(0.5, 1, 0.5), pick(ph.mobs()));
        b.setType(pick(ph.blocks()));
    }

    private List<Player> onlineMembers(Island is) {
        List<Player> l = new ArrayList<>();
        Player o = Bukkit.getPlayer(is.owner);
        if (o != null) l.add(o);
        for (UUID u : is.members) { Player p = Bukkit.getPlayer(u); if (p != null) l.add(p); }
        return l;
    }

    // ---------- undang / gabung ----------
    public void invite(Player p, Player t) {
        Island is = islands.get(p.getUniqueId());
        if (is == null) { p.sendMessage("§cBikin island dulu (/oneblock start), baru bisa mengundang!"); return; }
        if (t.equals(p)) { p.sendMessage("§cGak bisa undang diri sendiri!"); return; }
        if (is.members.contains(t.getUniqueId())) { p.sendMessage("§c" + t.getName() + " sudah jadi anggota!"); return; }
        plugin.getInviteManager().invite(p.getUniqueId(), t.getUniqueId());
        p.sendMessage("§aUndangan dikirim ke " + t.getName() + " (berlaku 60 detik).");
        t.sendMessage("§b" + p.getName() + " mengundang kamu ke island OneBlock! §7Ketik §e/oneblock §7atau §e/oneblock join " + p.getName());
    }

    public void join(Player p, UUID ownerId) {
        Island is = islands.get(ownerId);
        if (is == null || !plugin.getInviteManager().remove(p.getUniqueId(), ownerId)) {
            p.sendMessage("§cUndangan tidak ada atau sudah kadaluarsa!");
            return;
        }
        is.members.add(p.getUniqueId());
        active.put(p.getUniqueId(), ownerId);
        save();
        p.teleport(home(is));
        p.sendMessage("§aBerhasil gabung ke island " + name(ownerId) + "!");
        Player o = Bukkit.getPlayer(ownerId);
        if (o != null) o.sendMessage("§a" + p.getName() + " gabung ke island kamu!");
    }

    public void leave(Player p) {
        Island is = getIsland(p.getUniqueId());
        if (is == null || is.owner.equals(p.getUniqueId())) { p.sendMessage("§cKamu lagi di island sendiri."); return; }
        is.members.remove(p.getUniqueId());
        active.remove(p.getUniqueId());
        save();
        p.sendMessage("§eKamu keluar dari island " + name(is.owner));
        teleportHome(p);
    }

    public void kick(Player owner, UUID target) {
        Island is = islands.get(owner.getUniqueId());
        if (is == null || !is.members.remove(target)) { owner.sendMessage("§cDia bukan anggota island kamu."); return; }
        if (owner.getUniqueId().equals(active.get(target))) active.remove(target);
        save();
        owner.sendMessage("§e" + name(target) + " dikeluarkan dari island.");
        Player t = Bukkit.getPlayer(target);
        if (t != null) { t.sendMessage("§cKamu dikeluarkan dari island " + owner.getName()); teleportHome(t); }
    }

    // ---------- info ----------
    public List<String> stats(Island is) {
        Phase ph = phase(is.count), nx = nextPhase(is.count);
        List<String> l = new ArrayList<>();
        l.add("§7Pemilik: §f" + name(is.owner));
        l.add("§7Fase: " + ph.name());
        l.add("§7Blok dihancurkan: §a" + is.count);
        if (nx != null) l.add("§7Fase berikutnya: " + nx.name() + " §7(sisa §e" + (nx.from() - is.count) + "§7)");
        l.add("§7Anggota: §f" + is.members.size());
        return l;
    }

    public void info(Player p) {
        Island is = getIsland(p.getUniqueId());
        if (is == null) { p.sendMessage("§cKamu belum punya island. Ketik /oneblock start"); return; }
        p.sendMessage("§6§l== Info Island ==");
        stats(is).forEach(p::sendMessage);
    }

    public void top(Player p) {
        p.sendMessage("§6§l== Top OneBlock ==");
        List<Island> l = new ArrayList<>(islands.values());
        l.sort((a, b) -> Integer.compare(b.count, a.count));
        for (int i = 0; i < Math.min(10, l.size()); i++)
            p.sendMessage("§e#" + (i + 1) + " §f" + name(l.get(i).owner) + " §7- §a" + l.get(i).count + " blok");
        if (l.isEmpty()) p.sendMessage("§7Belum ada island.");
    }

    public String name(UUID id) {
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n == null ? "?" : n;
    }

    public Collection<UUID> membersOf(UUID owner) {
        Island is = islands.get(owner);
        return is == null ? List.of() : is.members;
    }
}
