package com.raja.oneblockgui.managers;

import com.raja.oneblockgui.OneBlockGUI;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Villager;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class NPCManager {

    private final OneBlockGUI plugin;
    private final List<Villager> spawnedNPCs = new ArrayList<>();

    public NPCManager(OneBlockGUI plugin) { this.plugin = plugin; }

    public Villager spawnNPC(Location loc) {
        Villager npc = create(loc);
        List<String> list = plugin.getConfig().getStringList("npc-locations");
        list.add(serialize(loc));
        plugin.getConfig().set("npc-locations", list);
        plugin.saveConfig();
        return npc;
    }

    private Villager create(Location loc) {
        Villager npc = loc.getWorld().spawn(loc, Villager.class, v -> {
            v.setAI(false);
            v.setInvulnerable(true);
            v.setSilent(true);
            v.setCollidable(false);
            v.setVillagerType(Villager.Type.PLAINS);
            v.setProfession(Villager.Profession.NITWIT);
            v.setCustomName(ChatColor.GOLD + "" + ChatColor.BOLD + "OneBlock");
            v.setCustomNameVisible(true);
            v.getPersistentDataContainer().set(plugin.getNpcKey(), PersistentDataType.BYTE, (byte) 1);
        });
        spawnedNPCs.add(npc);
        return npc;
    }

    public void loadFromConfig() {
        for (String s : plugin.getConfig().getStringList("npc-locations")) {
            Location loc = deserialize(s);
            if (loc == null || loc.getWorld() == null) continue;
            loc.getChunk().load();
            clearNear(loc, 2); // buang NPC lama biar gak dobel
            create(loc);
        }
    }

    private int clearNear(Location loc, double r) {
        int n = 0;
        for (Entity e : loc.getWorld().getNearbyEntities(loc, r, r, r)) {
            if (isOneBlockNPC(e)) { e.remove(); n++; }
        }
        spawnedNPCs.removeIf(v -> v.isDead() || !v.isValid());
        return n;
    }

    /** Hapus NPC terdekat + entri config-nya (biar gak muncul lagi pas restart). */
    public int removeNear(Location loc, double r) {
        int n = clearNear(loc, r);
        List<String> keep = new ArrayList<>();
        for (String s : plugin.getConfig().getStringList("npc-locations")) {
            Location l = deserialize(s);
            boolean near = l != null && l.getWorld() != null && l.getWorld().equals(loc.getWorld())
                    && l.distance(loc) <= r;
            if (!near) keep.add(s);
        }
        plugin.getConfig().set("npc-locations", keep);
        plugin.saveConfig();
        return n;
    }

    public void removeAllNPCs() {
        for (Villager v : spawnedNPCs) if (v != null && !v.isDead()) v.remove();
        spawnedNPCs.clear();
    }

    public boolean isOneBlockNPC(Entity entity) {
        return entity.getPersistentDataContainer().has(plugin.getNpcKey(), PersistentDataType.BYTE);
    }

    private String serialize(Location l) {
        return l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ() + ";" + l.getYaw() + ";" + l.getPitch();
    }

    private Location deserialize(String s) {
        try {
            String[] p = s.split(";");
            return new Location(Bukkit.getWorld(p[0]), Double.parseDouble(p[1]), Double.parseDouble(p[2]),
                    Double.parseDouble(p[3]), Float.parseFloat(p[4]), Float.parseFloat(p[5]));
        } catch (Exception e) {
            return null;
        }
    }
}
